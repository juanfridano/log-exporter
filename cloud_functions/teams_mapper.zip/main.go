package function

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
)

// ErrorReport represents the message sent from Error Reporting.
type ErrorReport struct {
	Subject       string        `json:"subject"`
	GroupInfo     GroupInfo     `json:"group_info"`
	ExceptionInfo ExceptionInfo `json:"exception_info"`
	EventInfo     EventInfo     `json:"event_info"`
}

// GroupInfo contains the link to the errors
type GroupInfo struct {
	Link string `json:"detail_link"`
}

// ExceptionInfo contains the exception infromation
type ExceptionInfo struct {
	Type    string `json:"type"`
	Message string `json:"message"`
}

// ExceptionInfo contains the exception infromation
type EventInfo struct {
	Message string `json:"log_message"`
}

// WebhookMapper is the entry point for the Cloud Function.
func WebhookMapper(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Only POST requests are allowed", http.StatusMethodNotAllowed)
		return
	}

	// Read the body of the request
	body, err := io.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "Failed to read request body", http.StatusInternalServerError)
		return
	}
	defer r.Body.Close()

	// For simplicity, just echo the body back in the response
	data := string(body)
	fmt.Fprintf(w, "Received request: %s", data)

	err = sendWebhook(data)
	if err != nil {
		logError(fmt.Sprintf("failed to send webhook: %v", err))
		return
	}
}

func sendWebhook(data string) error {
	webhookURL := os.Getenv("WEBHOOK_URL") // The webhook URL should be set as an environment variable.

	// Prepare the JSON payload
	var errorReport ErrorReport
	if err := json.Unmarshal([]byte(data), &errorReport); err != nil {
		return fmt.Errorf("could not parse received request into Error Reporting: %v", err.Error())
	}
	log(fmt.Sprint("Preparing teams webhook payload for alert with link: ", errorReport.GroupInfo.Link))
	payload := getTeamsPayload(errorReport)

	var jsonStr = []byte(payload)
	req, err := http.NewRequest("POST", webhookURL, bytes.NewBuffer(jsonStr))
	if err != nil {
		return fmt.Errorf("could not create request for Webhook: %v", err.Error())
	}
	req.Header.Set("X-Custom-Header", "myvalue")
	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("could not send request for Webhook: %v", err.Error())
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("unexpected status code: %d", resp.StatusCode)
	}

	return nil
}

func getTeamsPayload(errorReport ErrorReport) string {
	linkText := fmt.Sprint("[Link to Summary](", errorReport.GroupInfo.Link, ")")
	text := ""
	if len(errorReport.EventInfo.Message) > 0 {
		text = fmt.Sprint(text, "**Event Info Message**: ", trunc(errorReport.EventInfo.Message), "\n\n")
	}
	if len(errorReport.ExceptionInfo.Type) > 0 {
		text = fmt.Sprint(text, "**Exception Type**: ", trunc(errorReport.ExceptionInfo.Type), "\n\n")
	}
	if len(errorReport.ExceptionInfo.Message) > 0 {
		text = fmt.Sprint(text, "**Exception Message**: ", trunc(errorReport.ExceptionInfo.Message), "\n\n")
	}
	log(fmt.Sprintf("Payload created with subject: [%s], link: [%s]", errorReport.Subject, errorReport.GroupInfo.Link))

	return fmt.Sprintf(`
	{
		"type": "message",
		"summary": "new merge request data",
		"attachments": [
		{
			"contentType": "application/vnd.microsoft.card.adaptive",
			"contentUrl": null,
			"content": {
			"$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
			"version": "1.3",
			"type": "AdaptiveCard",
			"msteams": {
				"width": "Full"
			},
			"body": [
				{
				"type": "TextBlock",
				"weight": "Bolder",
				"text": "%s",
				"wrap": true,
				"size": "extraLarge",
				"color": "attention",
              	"style": "heading"
				},
				{
				"type": "TextBlock",
				"text": "%s",
				"wrap": true
				},
				{
				"type": "TextBlock",
				"text": "%s",
				"wrap": true
				}
			]
			}
		}
		]
	}`, errorReport.Subject, linkText, text)

}

func log(message string) {
	fmt.Printf(`{"message": "%s", "severity": "info"}%s`, message, "\n")
}
func logError(message string) {
	fmt.Printf(`{"message": "%s", "severity": "error"}%s`, message, "\n")
}
func trunc(message string) string {
	if len(message) > 500 {
		return fmt.Sprint(message[0:500], " [...]")
	}
	return message
}
